/**
 * Copyright © 2016 ITORIS INC. All rights reserved.
 * See license agreement for details
 */
var config = {
    map: {
        '*': {
            'form_tabs': 'Itoris_Producttabsslider/js/form_tabs',
            'grid_sort': 'Itoris_Producttabsslider/js/grid_sort',
            'variable': 'Itoris_Producttabsslider/js/variable'
        }
    }
};
