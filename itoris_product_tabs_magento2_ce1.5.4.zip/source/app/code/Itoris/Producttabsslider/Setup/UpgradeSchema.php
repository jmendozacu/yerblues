<?php
/**
 * ITORIS
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the ITORIS's Magento Extensions License Agreement
 * which is available through the world-wide-web at this URL:
 * http://www.itoris.com/magento-extensions-license.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to sales@itoris.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the extensions to newer
 * versions in the future. If you wish to customize the extension for your
 * needs please refer to the license agreement or contact sales@itoris.com for more information.
 *
 * @category   ITORIS
 * @package    ITORIS_M2_PRODUCT_TABS
 * @copyright  Copyright (c) 2016 ITORIS INC. (http://www.itoris.com)
 * @license    http://www.itoris.com/magento-extensions-license.html  Commercial License
 */

namespace Itoris\Producttabsslider\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        
        if (version_compare($context->getVersion(), '1.5.0') < 0) {
            $setup->run("INSERT INTO `{$setup->getTable('itoris_producttabs_tabs_attributes')}` (`attribute_id`, `attribute_code`, `backend_type`) VALUES ('7', 'categories', 'text');");
        }
        
        if (version_compare($context->getVersion(), '1.5.2') < 0) {
            //Removing ability to change order of tabs for store views because it causes logical issues. Order should be changed on the "all store views" level
            $setup->run("DELETE FROM `{$setup->getTable('itoris_product_tabs_value_int')}` WHERE `attribute_id`=3 AND `store_id` IS NOT NULL");
        }
        
        $setup->endSetup();
    }
}