<?php
namespace Impac\Tntalpha3\Model;

class Valoresoficina extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Impac\Tntalpha3\Model\ResourceModel\Valoresoficina');
    }
}
?>